<?php

use Faker\Generator as Faker;

$factory->define(App\APIEmployee::class, function (Faker $faker) {
    return [
        //
    ];
});
