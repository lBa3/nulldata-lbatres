@extends('layouts.app')

@section('content')

    <h1>Fura de linea</h1>

@endsection