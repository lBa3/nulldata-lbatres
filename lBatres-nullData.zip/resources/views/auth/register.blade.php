@extends('layouts.app')
@section('content')
<?php
header("Location: ./"); die();
?>
@endsection
