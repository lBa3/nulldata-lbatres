@extends('layouts.app')
@section('content')
<script>
    window.addEventListener('load', function () {
        var btnCreator = document.querySelector("#btCreator");
        btnCreator.addEventListener('click', function () {
            var combo = document.querySelector("#listelements");
            var id = combo.options[combo.selectedIndex].value;
            var name = combo.options[combo.selectedIndex].text;
            if (id == 0) {
                alert("Debes de seleccionar un skill de la lista");
            } else {
                CreatorDOM(id, name);
            }
        });
    });

    function CreatorDOM(id, name) {
        var selectedid = id;
        var selectedname = name;
        var temp = document.querySelector("#skill_id_" + selectedid);
        if (temp != null) {
            alert("El elemento ya existe.");
        } else {
            var dvChildrens = document.querySelector("#dvskill");
            var bloque = `
                       <div id="dvSkill_` + selectedid + `" class="col-md-4 skill text-center separador">
                        <h4 class="text-info">` + selectedname + `</h4>
                        <input name='skill_id_` + selectedid + `' id="skill_id_` + selectedid + `" type="text" class="noshow" value="` + selectedid + `" required>
                        </div>
                      `;
            dvChildrens.innerHTML += bloque;
            formats(selectedid);
        }
    }

    function formats(idA) {
        var id = idA;
        var ids = document.querySelector("#formats_id");
        ids.value += id + "|";
    }
</script>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Registro de empleado</div>
                <div class="card-body">
                    <form  id="formulario" class="form" method="POST" action="{{route('saveemployee')}}" onsubmit="return enviar();">
                        @csrf
                        <h2>Datos Generales</h2>   
                        <div class="form-group row">
                            <label for="name" class="col-md-3 col-form-label">{{ __('Nombre completo') }}</label>
                            <div class="col-md-9">
                                <input id="name" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="" required autofocus>
                                @if ($errors->has('name'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('name') }}</strong>
                                </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="email" class="col-md-3 col-form-label">{{ __('Email') }}</label>
                            <div class="col-md-9">
                                <input id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="" required autofocus>
                                @if ($errors->has('email'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('email') }}</strong>
                                </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="role" class="col-md-3 col-form-label">{{ __('Rol o Puesto') }}</label>
                            <div class="col-md-9">
                                <select class="form-control" id="role" class="form-control{{ $errors->has('role') ? ' is-invalid' : '' }}" name="role" value="" required autofocus>
                                    <option selected disabled>Seleecionar una opción...</option>
                                    <option value="1">ADMINISTRADOR</option>
                                    <option value="2">FINANZAS</option>
                                </select>
                                @if ($errors->has('role'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('role') }}</strong>
                                </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="birthdate" class="col-md-3 col-form-label">{{ __('Fecha de nacimiento') }}</label>
                            <div class="col-md-9">
                                <input id="birthdate" type="date" class="form-control{{ $errors->has('birthdate') ? ' is-invalid' : '' }}" name="birthdate" value="" required autofocus>
                                @if ($errors->has('birthdate'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('birthdate') }}</strong>
                                </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="address" class="col-md-3 col-form-label">{{ __('Domicilio') }}</label>
                            <div class="col-md-9">
                                <textarea class="form-control" id="address" name="address" rows="3" required></textarea>     
                            </div>
                        </div>
                        <hr/>
                        <h2>Skills</h2>
                        <div class="input-group">
                            <select class="custom-select" id='listelements' value="" required autofocus>
                                <option selected disabled>Seleccione skill's de la lista ...</option>
                                <option value="1">Proactivo</option>
                                <option value="2">Orientado a objetivos</option>
                                <option value="3">Buen lider</option>
                            </select>
                            <div class="input-group-append">
                                <button  id="btCreator" class="btn btn-outline-dark" type="button"><span class="fa fa-check-circle"></span> Seleccionar</button>
                            </div>     
                        </div>
                        <div id="dvskill" class="row col-md-12"></div>
                        <input id="cskill"  class="noshow" name="cskill" value="" >
                        <input type="text" name="formats_id" class="noshow" id="formats_id" value="" required/>
                        <hr/>
                        <div class="form-group row mb-0">
                            <div class="col-md-12 text-center">
                                <a href="{{route('home')}}" class="btn btn-danger btn-lg btn-block">
                                    {{ __('Cancelar') }}
                                </a>
                            </div>
                        </div>
                        <br/>
                        <hr/>
                        <div class="form-group row mb-0">
                            <div class="col-md-12 text-center">
                                <button type="submit" class="btn btn-success btn-lg btn-block">
                                    {{ __('Guardar') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    function enviar() {
        var formulario = document.getElementById("formulario");
        var e = document.getElementsByClassName("skill");
        var skills = e.length;
        if (skills >= 1) {
            var $n = $("#cskill").val(skills);
            formulario.submit();
            return true;
        } else {
            alert("Tienes que seleccionar almenos un skill de la lista");
            return false;
        }

    }
</script>
@endsection