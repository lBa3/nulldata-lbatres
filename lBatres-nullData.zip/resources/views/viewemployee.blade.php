@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Detalle del empleado</div>
                <div class="card-body">
                        <h2>Datos Generales</h2>   
                        <div class="form-group row">
                            <label for="name" class="col-md-3 col-form-label">{{ __('Nombre completo') }}</label>
                            <div class="col-md-9">
                                <label for="name" class="col-md-9 col-form-label">{{$employee->name}}</label>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="email" class="col-md-3 col-form-label">{{ __('Email') }}</label>
                            <div class="col-md-9">
                                 <label for="email" class="col-md-9 col-form-label">{{$employee->email}}</label>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="role" class="col-md-3 col-form-label">{{ __('Rol o Puesto') }}</label>
                            <div class="col-md-9">
                                 <label for="role" class="col-md-9 col-form-label">{{$role}}</label>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="birthdate" class="col-md-3 col-form-label">{{ __('Fecha de nacimiento') }}</label>
                            <div class="col-md-9">
                                <label for="birthdate" class="col-md-9 col-form-label">{{$employee->birthdate}}</label>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="address" class="col-md-3 col-form-label">{{ __('Domicilio') }}</label>
                            <div class="col-md-9">
                                <label for="address" class="col-md-9 col-form-label">{{$employee->address}}</label>   
                            </div>
                        </div>
                        <hr/>
                        <h2>Skills</h2>
                        <div id="dvskill" class="row col-md-12">
                              @foreach($skills as $h => $skill)
                                @if($skill->skill == "1")
                                <div class="col-md-4 text-info"><h4>Proactivo</h4></div>
                                @endif
                                @if($skill->skill == "2")
                                <div class="col-md-4 text-info"><h4>Orientado a objetivos</h4></div>
                                @endif
                                @if($skill->skill == "3")
                                <div class="col-md-4 text-info"><h4>Buen lider</h4></div>
                                @endif
                              @endforeach
                        </div>
                        <hr/>
                        <div class="form-group row mb-0">
                            <div class="col-md-12 text-center">
                                <a href="{{route('home')}}" class="btn btn-danger btn-lg btn-block">
                                    {{ __('Cancelar') }}
                                </a>
                            </div>
                        </div>
                        <br/>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection