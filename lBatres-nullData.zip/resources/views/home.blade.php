@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Principal</div>
                <div class="card-body">
                    @if (session('status'))
                    <div class="alert alert-success" role="alert">
                        {{ session('status') }}
                    </div>
                    @endif
                    <div class="row">
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-6">
                                    <h2>API</h2>
                                    <p>Permitir el registro de un empleado con los siguientes campos: </p>
                                    <p>nombre, email, puesto, fecha de nacimiento (formato dd/mm/yyyy), domicilio, y al menos un skill. </p>
                                    <p>* Se debe permitir registrar más de un skill.</p>
                                    <p>* Realizar validaciones de formato de datos. </p>
                                    <p>* Listado de los empleados.</p>
                                    <p>* Consultar la información de un empleado.</p>
                                    <p>{employees}</p>
                                    <p>{GetOneEmployee/2}</p>
                                    <p>{CreateEmployee}</p>
                                    <hr/>
                                </div>
                                <div class="col-md-6">
                                    @include('includes.message')
                                    <h2>PWA</h2>
                                    <p>Se debe mostrar un formulario de registro con los siguientes campos: </p>
                                    <p>nombre, email, fecha de nacimiento (formato dd/mm/yyyy) y domicilio (Calle, num ext, colonia, etc).</p>
                                    <p>* Realizar validaciones de formato de datos.</p>
                                    <p>* Ver un listado de las personas registradas en una tabla. </p>
                                    <p>* Usar un mecanismo de persistencia Web (IndexedDB, Local Storage, Web SQL…).</p>
                                    <hr/>
                                    <a href="{{route('registeremployee')}}" class="btn btn-block btn-info">Ingresar Empleado</a>
                                    <a href="{{route('listemployees')}}" class="btn btn-block btn-info">Listar Empleados</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
