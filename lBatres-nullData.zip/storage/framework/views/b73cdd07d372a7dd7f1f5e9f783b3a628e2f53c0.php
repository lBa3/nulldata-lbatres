<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Detalle del empleado</div>
                <div class="card-body">
                        <h2>Datos Generales</h2>   
                        <div class="form-group row">
                            <label for="name" class="col-md-3 col-form-label"><?php echo e(__('Nombre completo')); ?></label>
                            <div class="col-md-9">
                                <label for="name" class="col-md-9 col-form-label"><?php echo e($employee->name); ?></label>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="email" class="col-md-3 col-form-label"><?php echo e(__('Email')); ?></label>
                            <div class="col-md-9">
                                 <label for="email" class="col-md-9 col-form-label"><?php echo e($employee->email); ?></label>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="role" class="col-md-3 col-form-label"><?php echo e(__('Rol o Puesto')); ?></label>
                            <div class="col-md-9">
                                 <label for="role" class="col-md-9 col-form-label"><?php echo e($role); ?></label>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="birthdate" class="col-md-3 col-form-label"><?php echo e(__('Fecha de nacimiento')); ?></label>
                            <div class="col-md-9">
                                <label for="birthdate" class="col-md-9 col-form-label"><?php echo e($employee->birthdate); ?></label>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="address" class="col-md-3 col-form-label"><?php echo e(__('Domicilio')); ?></label>
                            <div class="col-md-9">
                                <label for="address" class="col-md-9 col-form-label"><?php echo e($employee->address); ?></label>   
                            </div>
                        </div>
                        <hr/>
                        <h2>Skills</h2>
                        <div id="dvskill" class="row col-md-12">
                              <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h => $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($skill->skill == "1"): ?>
                                <div class="col-md-4 text-info"><h4>Proactivo</h4></div>
                                <?php endif; ?>
                                <?php if($skill->skill == "2"): ?>
                                <div class="col-md-4 text-info"><h4>Orientado a objetivos</h4></div>
                                <?php endif; ?>
                                <?php if($skill->skill == "3"): ?>
                                <div class="col-md-4 text-info"><h4>Buen lider</h4></div>
                                <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <hr/>
                        <div class="form-group row mb-0">
                            <div class="col-md-12 text-center">
                                <a href="<?php echo e(route('home')); ?>" class="btn btn-danger btn-lg btn-block">
                                    <?php echo e(__('Cancelar')); ?>

                                </a>
                            </div>
                        </div>
                        <br/>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>