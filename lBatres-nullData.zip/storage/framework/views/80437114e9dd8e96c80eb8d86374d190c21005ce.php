<?php if(session('code_200')): ?>
<div class="alert alert-success text-success text-center alert-dismissible fade show" role="alert">
  <strong><span class="fa fa-bell"></span></strong> <?php echo e(session('code_200')); ?>

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php endif; ?> 




