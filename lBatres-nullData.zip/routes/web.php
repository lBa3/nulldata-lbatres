<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});



Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');


//Vistas
Route::get('/RegisterEmployee', 'EmployeeController@Register')->name('registeremployee');
Route::post('/SaveEmployee', 'EmployeeController@SaveEmployee')->name('saveemployee');
Route::get('/ListEmployees', 'EmployeeController@List')->name('listemployees');
Route::get('/GetDataEmployee/{id}', 'EmployeeController@GetDataEmployee')->name('getdataemployee');

//wpa
Route::get('/offline', function () {    
    return view('modules/laravelpwa/offline');
});


