<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Employee;
use App\EmployeeSkill;

class EmployeeController extends Controller
{
    
    public function Register(){
        return view('registeremployee');
    }
    
    public function SaveEmployee(Request $request){
        
         $validate = $this->validate($request,[
           'name'  => 'required|string|max:255',
           'role'  => 'required|integer',
           'birthdate'  => 'required',
           'email' => 'required|string|email|max:255|unique:users,email',
           'address' => 'required|string|max:500',
        ]);
        
        $name      = $request->input('name');
        $role      = $request->input('role');
        $birthdate = $request->input('birthdate');
        $email     = $request->input('email');
        $address   = $request->input('address');
        $employee = new Employee();
        $employee->name = $name;
        $employee->birthdate  = $birthdate;
        $employee->address  = $address;
        $employee->email  = $email;
        $employee->role  = $role;
        $employee->save();
        $id = $employee->id;
        
        $f = $request->input('formats_id');
        $t = explode('|', $f);
        
        $c    = $request->input('cskill');
        for($i = 0; $i < $c; $i++){
            $v = $t[$i];
            $dd = $request->input('skill_id_'.$v);
            $employeeSkill = new EmployeeSkill();
            $employeeSkill->employee_id = $id;
            $employeeSkill->skill = $v;
            $employeeSkill->save();
        }
        
        return redirect()->route('home')->with(['code_200' => "Registro insertado correctamente."]);
        
    }
    
    public function  List(){
        $employees= Employee::select('*')->orderBy('id', 'DESC')->get();
        return view('listeremployees',['employees' => $employees]);
    }
    
    public function GetDataEmployee($id){
        $employee= Employee::select('employees.id', 'employees.name', 'employees.birthdate', 'employees.address', 'employees.X', 'employees.Y', 'employees.email', 'employees.role', 'employeeskill.skill')
                ->join('employeeskill', 'employeeskill.employee_id', '=', 'employees.id')
                ->where('employees.id', '=', $id)
                ->get();
        
         $skills= EmployeeSkill::select('skill')
                ->where('employee_id', '=', $id)
                ->get();
        
        if ($employee[0]->role == 1){
           $role = "ADMINISTRADOR";
        }else{
           $role = "FINANZAS"; 
        }
        
        
        return view('viewemployee',['employee' => $employee[0], 'role'=> $role, 'skills' => $skills]);
    }
    
   
    
    
}
