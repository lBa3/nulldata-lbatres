<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\APIEmployee;
use App\EmployeeSkill;

class APIEmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(){
        $employees= APIEmployee::select('*')->orderBy('id', 'DESC')->get();
        return $employees;
    }
    
    public function getoneemployee($id){
        $employee= APIEmployee::select('*')->where('id', '=', $id)->get();
        return  $employee;
    }
    
    public function createeployee(Request $request){
        
        try
    {
        $validate = $this->validate($request,[
               'name'  => 'required|string|max:255',
               'role'  => 'required|integer',
               'birthdate'  => 'required|date_format:d/m/Y',
               'email' => 'required|string|email|max:255|unique:users,email',
               'address' => 'required|string|max:500',
               'total_skills' => 'required|integer|min:1',
               'skills_label' => 'required|string|min:1',
            ]);
    }
    catch(\Exception $e)
    {
        return $e;
    }
    
    try
    {
       $employee = new APIEmployee();
       $employee->name  = $request->name;
       $employee->birthdate  = $request->birthdate;
       $employee->address  = $request->address;
       $employee->email  = $request->email;
       $employee->role  = $request->role;
       $employee->save();
       $id = $employee->id;
       
       $t = $request->total_skills;
       $la = explode('|', $request->skills_label);
       
       for($i = 0; $i < $t; $i++){
            $v = $la[$i];
            $employeeSkill = new EmployeeSkill();
            $employeeSkill->employee_id = $id;
            $employeeSkill->skill = $v;
            $employeeSkill->save();   
       }
       
       return $employee;
    }
    catch(\Exception $e)
    {
        return $e;
    }
    

      
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
//    public function create()
//    {
//        //
//    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\APIEmployee  $aPIEmployee
     * @return \Illuminate\Http\Response
     */
    public function show(APIEmployee $aPIEmployee)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\APIEmployee  $aPIEmployee
     * @return \Illuminate\Http\Response
     */
//    public function edit(APIEmployee $aPIEmployee)
//    {
//        //
//    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\APIEmployee  $aPIEmployee
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, APIEmployee $aPIEmployee)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\APIEmployee  $aPIEmployee
     * @return \Illuminate\Http\Response
     */
    public function destroy(APIEmployee $aPIEmployee)
    {
        //
    }
}
