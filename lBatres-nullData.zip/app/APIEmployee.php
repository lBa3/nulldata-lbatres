<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class APIEmployee extends Model
{
    protected $table = 'employees';
    //protected  $filltable = array('name', 'birthdate', 'address', 'email', 'role');
}
